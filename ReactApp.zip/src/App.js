import "./style.css"
import Cars from "./Cars"
function App() {
  return (
    <div id="main">
      <h1 className="black">hello world</h1>
      <Cars title="audi" price="400" />
      <Cars title="bmw" price="800" />
      <Cars title="civic" price="600" />
    </div>

  );
}

export default App;
