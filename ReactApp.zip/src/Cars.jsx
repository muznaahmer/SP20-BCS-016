import React from 'react';

const Cars = (props) => {
    var title = props.title;
    var price = props.price;
    var setColor = price <= 400 ? "pink" : "cyan";
    // console.log(title)
    return (
        <div>
            <h1>{title}</h1>
            <b className={setColor}>Price: {price}</b>
        </div>
    );
}

export default Cars;