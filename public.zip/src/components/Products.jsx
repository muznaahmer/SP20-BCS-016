import React from 'react';

const Products = () => {
    return ( <div>
        <h1>products</h1>
    </div> );
}
 
export default Products;