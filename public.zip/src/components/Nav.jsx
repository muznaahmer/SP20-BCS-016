import React, { useState } from "react";
import { AppBar, Tabs, Tab, Toolbar, Button } from "@mui/material";
import CheckroomIcon from "@mui/icons-material/Checkroom";
import { useNavigate } from "react-router";
// import Home from './Home';
// import Products from './Products';
// import ContactUs from './ContactUs';
const NavBar = () => {
  const [value, setValue] = useState();
  const navigate = useNavigate();
  const clickme = () => {
    navigate("/home");
    console.log("Clicked...");
  };

  //       const[selectedTab,setSelectedTab]= React.useState(0);
  //       const handleChange = (event,newValue)=>{
  //       setSelectedTab(newValue);
  //   };

  return (
    <React.Fragment>
      <AppBar sx={{ background: "#063970" }} position="static">
        <Toolbar>
          <CheckroomIcon />

          <Tabs
            sx={{ marginLeft: "auto" }}
            textColor="inherit"
            value={value}
            onChange={(e, value) => setValue(value)}
            indicatorColor="primary"
          >
            <Tab label="Home" onClick={clickme} />
            <Tab label="Products" />
            <Tab label="Contact Us" />
          </Tabs>
          <Button sx={{ marginLeft: "15px" }} variant="contained">
            Login
          </Button>
          <Button sx={{ marginLeft: "15px" }} variant="contained">
            SignUp
          </Button>
        </Toolbar>
      </AppBar>
      {/* {selectedTab ===0 && <Home/>}
        {selectedTab ===1 && <Products/>}
        {selectedTab ===2 && <ContactUs/>} */}
    </React.Fragment>
  );
};

export default NavBar;
