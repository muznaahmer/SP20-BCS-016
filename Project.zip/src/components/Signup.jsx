import React, { useState } from "react";

const Signup = () => {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [date, setDate] = useState("");
  const collect = () => {
    console.log(name, email, password, date);
  };

  return (
    <div className="input1">
      <h1> Sign Up</h1>
      <input
        className="input-box"
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="enter name"
      />
      <input
        className="input-box"
        type="text"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="enter e-mail"
      />
      <input
        className="input-box"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="enter password"
      />

      <input
        className="input-box"
        value={date}
        onChange={(e) => setDate(e.target.value)}
        type="date"
      />
      <button onClick={collect} className="input-button" type="button">
        Sign Up
      </button>
    </div>
  );
};

export default Signup;
