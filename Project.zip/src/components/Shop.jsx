import React from 'react'
import Button from '@mui/material/Button'

const button = {
    margin: "15px",
    backgroundColor: "black"
}
const Shop = () => {
    return ( 
        <div>
        <Button sx={button} variant = "contained">Add Product</Button>
        <Button sx={button} variant = "contained">Remove Product</Button>
        </div>
     );
}
 
export default Shop;