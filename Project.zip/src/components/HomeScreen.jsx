import React from "react";

const HomeScreen = () => {
  return (
    <div className="main">
      <h1>Home</h1>
    </div>
  );
};

export default HomeScreen;
