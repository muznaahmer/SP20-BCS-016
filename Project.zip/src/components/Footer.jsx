import React from 'react'


const Footer = () => {
    return (<div className='foot'>
        <div>
        <h3>Shopping-Mart</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro, iste? Eligendi suscipit autem dicta odio distinctio similique debitis, quos, perspiciatis laboriosam voluptas nam sequi unde accusamus et delectus excepturi temporibus?</p>
        </div>
    </div>  );
}
 
export default Footer;