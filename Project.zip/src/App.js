
import './App.css';
import Header from './components/Header';
import {Routes , Route} from 'react-router-dom';
import Footer from './components/Footer';
import Signup from './components/Signup';
import HomeScreen from './components/HomeScreen';
import Shop from './components/Shop';

function App() {
  return (
    
    <div className="App">

      <Header/>
  
  
  <Routes>
    <Route path='/' element={<HomeScreen/>} />
    <Route path='/shop' element={<Shop/>}/>
    <Route path='/contactus' element={<h1>Contact Us </h1>}/>
    <Route path='/signup' element={<Signup/>} />
  </Routes>
     <Footer/>

    </div>
  
  );
}

export default App;
